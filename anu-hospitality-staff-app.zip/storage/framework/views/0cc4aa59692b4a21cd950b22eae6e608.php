<header>

    <!-- Top Contact Bar -->
    <div class="sub-header">
    <div class="sub-header-container">

        <!-- Left: Contact Info -->
        <div class="contact-info">
            <a href="mailto:info@anuhospitality.com">
                <i class="fa-solid fa-envelope"></i> info@anuhospitality.com
            </a>
            <a href="tel:+441234567890">
                <i class="fa-solid fa-phone"></i> +44 7459 292378
            </a>
        </div>

        <!-- Right: Social Links -->
        <div class="social-links">
            <a href="https://www.facebook.com/" target="_blank" aria-label="Facebook">
                <i class="fa-brands fa-facebook-f"></i>
            </a>

            <a href="https://www.linkedin.com/" target="_blank" aria-label="LinkedIn">
                <i class="fa-brands fa-linkedin-in"></i>
            </a>

            <a href="https://www.instagram.com/" target="_blank" aria-label="Instagram">
                <i class="fa-brands fa-instagram"></i>
            </a>
        </div>

    </div>
</div>


    <!-- Desktop Header -->
    <div class="main-header">
        <div class="header-container">

            <a href="<?php echo e(url('/')); ?>" class="logo">
                <img src="<?php echo e(asset('assets/logos/logo.webp')); ?>" class="site-logo">
            </a>

            <nav class="main-nav">
                <ul>
                    <li><a href="<?php echo e(url('/#hero')); ?>" class="hover-underline">Home</a></li>
                    <li><a href="<?php echo e(url('/#about-us')); ?>" class="hover-underline">About</a></li>
                    <li><a href="<?php echo e(url('/services')); ?>" class="hover-underline">Services</a></li>
                    <li><a href="<?php echo e(url('/vacancies')); ?>" class="hover-underline">Vacancies</a></li>
                    <li><a href="<?php echo e(url('/domestic')); ?>" class="hover-underline">Domestic Cleaning</a></li>
                    <li><a href="<?php echo e(url('/#contact-us')); ?>" class="hover-underline">Contact</a></li>
                </ul>
            </nav>

            <div class="nav-buttons">

                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-secondary">My Account</a>
                <?php else: ?>
                    <a href="<?php echo e(url('/login')); ?>" class="btn btn-secondary">Login</a>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <!-- Mobile Header -->
    <div class="mobile-header">
        <div class="header-container">
            <a href="<?php echo e(url('/')); ?>" class="mobile-logo">
                <img src="<?php echo e(asset('assets/logos/logo.webp')); ?>" class="site-logo">
            </a>

            <div class="menu-toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
        </div>

        <nav class="mobile-nav">
            <div class="mobile-nav-top">
                <span class="logo-text">ANU HOSPITALITY STAFF</span>
                <span class="close-menu">
                    <i class="fa-solid fa-xmark"></i>
                </span>
            </div>

            <ul>
                <li><a href="<?php echo e(url('/#hero')); ?>">Home</a></li>
                <li><a href="<?php echo e(url('/#about-us')); ?>">About</a></li>
                <li><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                <li><a href="<?php echo e(url('/vacancies')); ?>">Vacancies</a></li>
                <li><a href="<?php echo e(url('/domestic')); ?>">Domestic Cleaning</a></li>
                <li><a href="<?php echo e(url('/#contact-us')); ?>">Contact</a></li>
            </ul>

            <div class="nav-buttons-mobile">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-secondary">My Account</a>
                <?php else: ?>
                    <a href="<?php echo e(url('/login')); ?>" class="btn btn-secondary">Login</a>
                <?php endif; ?>
            </div>
        </nav>

        <div class="menu-overlay"></div>
    </div>

</header>
<?php /**PATH C:\xampp\htdocs\anu-hospitality-staff-app\resources\views/partials/header.blade.php ENDPATH**/ ?>